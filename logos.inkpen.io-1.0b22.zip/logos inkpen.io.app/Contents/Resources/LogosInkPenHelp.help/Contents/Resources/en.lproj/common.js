// Footer loading disabled
// document.addEventListener('DOMContentLoaded', function() {
//     // Footer removed
// });